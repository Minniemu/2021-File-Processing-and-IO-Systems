#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/fs.h>
// #ifndef BLKRASIZE
#define BLKRASET _IO(0x12,98)
// #endif
#define BLKRAGET _IO(0x12,99)
#ifndef BLKGETSIZE
#define BLKGETSIZE _IO(0x12,96)
#endif

#ifndef BLKPBSZGET
#define BLKSSZGET _IO(0x12,104)
#endif
extern int errno ;
int main(int argc, char **argv)
{
	unsigned long size = 0,logicalsectsize = 0,readahead = 64,get_readahead = 0;
	double finalsize;
	int fd = open("/dev/sda4",O_RDWR);
	
	printf("%d\n",fd );
	if (ioctl(fd, BLKSSZGET, &logicalsectsize)<0)
		logicalsectsize = 0;
	printf("HDD's sector size:%lu\n",logicalsectsize );
	if(ioctl(fd, BLKGETSIZE, &size) != 0)
		printf("size:%lu\n",size );
	if(ioctl(fd, BLKRASET, readahead)!= 0)

		printf("in \n");
	ioctl(fd, BLKRAGET, &get_readahead);
	// if(ioctl(fd, BLKRAGET, &get_readahead) != 0)
	printf("readahead : %lu\n",get_readahead );
	printf("HDD's block:%lu\n",size );
	finalsize = (double)size*logicalsectsize/(1024*1024*1024);
	printf("Actual size are :%lu*%lu/(1024*1024*1024) = %f GB\n",size,logicalsectsize,finalsize );

}